#!/usr/bin/env python3
"""
Corrected-engine replay for the IEPF Contact Finder.

Runs the APPROVED correction rules over the REAL cached evidence
(.cache/investigations.json) and shows before/after. This validates the
deterministic corrections (anchor gate, evidence-bounded acceptance, domain
de-dup, dual scoring, four-sheet output, no fallback) on real data, without
needing live fetch / API keys.

It CANNOT show the effect of turning off Gemini's live search or the full
ingestion rewrite, because those change what evidence is captured upstream.
So the improvement shown here is a LOWER BOUND: the real fix removes even
more noise before scoring.
"""
import json, csv, re, os, collections
from urllib.parse import urlparse

CACHE = ".cache/investigations.json"
OUT = "/mnt/user-data/outputs/corrected_output"
os.makedirs(OUT, exist_ok=True)

# ---------------------------------------------------------------- config (from approved plan)
MIN_REPORTABLE = 25
DAILY_CAP = 50
MAX_CONTACTS_PER_CASE = 3
GENERIC_CROSS_SUBJECT_THRESHOLD = 5   # a phone seen for >=5 distinct subjects = directory/generic
FOREIGN_MARKERS = ["UNITED ARAB", "DUBAI", "U.A.E", "UAE", "P O BOX", "PO BOX",
                   "SAUDI", "QATAR", "OMAN", "KUWAIT", "SINGAPORE", "U.S.A", "USA",
                   "UNITED KINGDOM", "LONDON", "CANADA", "AUSTRALIA"]

# ---------------------------------------------------------------- helpers
STOP = {"C","O","S","D","W","R","MR","MRS","MS","SHRI","SMT","KUMARI","LATE","THE","AND"}

def norm(s):
    return re.sub(r"[^A-Z0-9 ]", " ", (s or "").upper())

def tokens(s):
    return [t for t in norm(s).split() if len(t) > 1 and t not in STOP]

def clean_name(raw):
    """Ingestion fix (light): cut care-of glued onto the name."""
    up = (raw or "").upper()
    up = re.split(r"C\s*/\s*O|CARE OF|S\s*/\s*O|D\s*/\s*O|W\s*/\s*O", up)[0]
    return up.strip()

def care_of_name(addr):
    m = re.search(r"C\s*/\s*O\s*([A-Z][A-Z .]{2,40})", (addr or "").upper())
    return tokens(m.group(1)) if m else []

def lev(a, b):
    if a == b: return 0
    if abs(len(a) - len(b)) > 2: return 3
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[-1] + 1, prev[j-1] + (ca != cb)))
        prev = cur
    return prev[-1]

def token_in(tok, text_tokens):
    return any(lev(tok, w) <= 1 for w in text_tokens)

def is_dummy(phone):
    if not phone or not re.fullmatch(r"[6-9]\d{9}", phone): return True
    if len(set(phone)) <= 3: return True                      # 9999999999, 9090909090
    if phone in {"1234567890","0000000000"}: return True
    if phone[1:] == phone[0]*9: return True
    if re.search(r"(\d)\1{4,}", phone): return True           # any digit run >=5 (e.g. 6950000022)
    if re.search(r"0{4,}", phone): return True                # templated list numbers 69x0000yy
    asc = "".join(str((int(phone[0])+i) % 10) for i in range(10))
    if phone == asc: return True
    return False

# multi-person LIST sources: a name co-occurring with a number here does NOT prove ownership
LIST_SOURCES = ("scribd.com", "pdfcoffee", "slideshare", "docplayer", "coursehero")
# pages that are not contact directories at all (harvested wholesale)
NON_CONTACT_PAGES = ("billstatus", "billstatu", "frmcancel", "autho/", "/cr/", "delvat")

def source_flags(ev):
    doms = [domain(e.get("sourceUrl","")).lower() for e in ev]
    urls = [(e.get("sourceUrl","") or "").lower() for e in ev]
    is_list = any(any(s in d for s in LIST_SOURCES) for d in doms) or \
              any(".pdf" in u or "filetype" in u for u in urls)
    is_noncontact = any(any(s in u for s in NON_CONTACT_PAGES) for u in urls)
    non_list_domains = {d for d in doms if d and not any(s in d for s in LIST_SOURCES)}
    return is_list, is_noncontact, len(non_list_domains)

def domain(url):
    try: return urlparse(url).hostname or ""
    except Exception: return ""

GOV = ("gov.in", "nic.in", "mca.gov")
DIRECTORY = ("justdial", "indiamart", "tradeindia", "sulekha", "yellowpages",
             "exportersindia", "quickcompany", "zaubacorp")

# ---------------------------------------------------------------- name match (token-based, not single-word)
def name_match(subject_tokens, surname, text):
    tt = tokens(text)
    if not subject_tokens: return "NONE"
    hits = sum(1 for t in subject_tokens if token_in(t, tt))
    if hits == len(subject_tokens) and len(subject_tokens) >= 2:
        exact = all(t in tt for t in subject_tokens)
        return "EXACT" if exact else "VARIANT"
    if hits == len(subject_tokens) and len(subject_tokens) == 1:
        # single-token full names are too weak to call EXACT on a directory page
        return "PARTIAL"
    if surname and token_in(surname, tt):
        return "SURNAME_ONLY"
    if hits >= 1:
        return "PARTIAL"
    return "NONE"

# ---------------------------------------------------------------- the ANCHOR GATE (the core fix)
def evaluate_candidate(cand, subj, generic_phones):
    """Returns dict with corrected decision on real captured evidence."""
    phone = cand.get("phone", "")
    reasons = []

    if is_dummy(phone):
        return {"phone": phone, "keep": False, "category": "Rejected", "reason": "DUMMY_OR_SPAM"}
    if phone in generic_phones:
        return {"phone": phone, "keep": False, "category": "Rejected", "reason": "DIRECTORY_GENERIC_NUMBER"}
    if subj["foreign"]:
        return {"phone": phone, "keep": False, "category": "Rejected", "reason": "OUT_OF_SCOPE_FOREIGN_ADDRESS"}

    ev = cand.get("evidence", []) or []
    # domain de-dup: distinct domains, not distinct URLs
    dom = {domain(e.get("sourceUrl","")) for e in ev if domain(e.get("sourceUrl",""))}
    distinct_domains = len(dom)

    # best name match across evidence blocks (block-bounded: snippet IS the local block)
    best_nm = "NONE"
    rank = {"EXACT":4,"VARIANT":3,"SURNAME_ONLY":2,"PARTIAL":1,"NONE":0}
    anchor_house = anchor_area = anchor_careof = False
    for e in ev:
        blk = (e.get("snippet","") + " " + (e.get("ownerName","") or ""))
        nm = name_match(subj["name_tokens"], subj["surname"], blk)
        if rank[nm] > rank[best_nm]: best_nm = nm
        bt = tokens(blk)
        if subj["house"] and re.search(r"\b"+re.escape(subj["house"])+r"\b", norm(blk)): anchor_house = True
        if subj["area_tokens"] and sum(1 for a in subj["area_tokens"] if token_in(a, bt)) >= 1: anchor_area = True
        if subj["careof_tokens"] and all(token_in(c, bt) for c in subj["careof_tokens"]): anchor_careof = True

    # ---- MANDATORY ANCHOR GATE ----
    identity_anchor  = best_nm in ("EXACT","VARIANT")
    family_anchor    = anchor_careof
    premises_anchor  = (anchor_house and anchor_area)
    weak_premises    = (best_nm == "SURNAME_ONLY" and (anchor_house or anchor_area))

    if not (identity_anchor or family_anchor or premises_anchor or weak_premises):
        return {"phone": phone, "keep": False, "category": "Rejected",
                "reason": f"NO_ANCHOR(name={best_nm},house={anchor_house},area={anchor_area},careof={anchor_careof})"}

    # ---- DUAL SCORE (0-100 each) ----
    # relationship strength: contact owner <-> shareholder/premises
    rel = 0
    if identity_anchor:  rel += 55 if best_nm == "EXACT" else 40
    if family_anchor:    rel += 30
    if premises_anchor:  rel += 35
    elif weak_premises:  rel += 15
    rel = min(100, rel)
    # contact reliability: phone <-> its identified owner
    rec = 20
    if cand.get("owner"): rec += 15
    if distinct_domains >= 2: rec += 25          # independent corroboration (distinct domains only)
    if any(g in domain(e.get("sourceUrl","")) for e in ev for g in GOV): rec += 25
    elif any(d in domain(e.get("sourceUrl","")) for e in ev for d in DIRECTORY): rec += 5
    rec = min(100, rec)

    # ---- SOURCE GUARDS ----
    is_list, is_noncontact, non_list_domains = source_flags(ev)
    if is_noncontact:
        return {"phone": phone, "keep": False, "category": "Rejected",
                "reason": "NON_CONTACT_PAGE(bill/status/gov-form harvested wholesale)"}

    # ---- CLASSIFY (stricter: A/B require identity; premises alone -> manual) ----
    if identity_anchor and rel >= 55 and not is_noncontact:
        cat = "A"   # Direct
    elif (identity_anchor and premises_anchor) or (family_anchor and best_nm in ("EXACT","VARIANT","SURNAME_ONLY")):
        cat = "B"   # Connected
    elif premises_anchor and best_nm in ("EXACT","VARIANT","SURNAME_ONLY"):
        cat = "C"   # Premises (same premises AND at least a surname; not a bare house-number coincidence)
    else:
        cat = "D"   # Research lead -> manual review, never the call sheet

    # LIST-PDF guard: a shareholder-list PDF alone cannot support A/B; needs a 2nd non-list domain
    if cat in ("A","B") and is_list and non_list_domains < 1:
        cat = "D"
        reasons.append("list-PDF only, no independent corroboration -> manual review")

    return {"phone": phone, "keep": cat in ("A","B","C"), "category": cat,
            "reason": f"anchor ok; name={best_nm} house={anchor_house} area={anchor_area} careof={anchor_careof}",
            "rel": rel, "rec": rec, "owner": cand.get("owner"), "nm": best_nm,
            "domains": distinct_domains,
            "source": (ev[0].get("sourceUrl","") if ev else "")}

# ---------------------------------------------------------------- load + prep
data = json.load(open(CACHE))
records = list(data.values())

# cross-subject frequency: a phone attributed to many different people = directory/generic
phone_subjects = collections.defaultdict(set)
for r in records:
    subj_key = norm(clean_name(r["subject"]["name"]))
    for p in r["phones"]:
        phone_subjects[p.get("phone","")].add(subj_key)
generic_phones = {ph for ph, subs in phone_subjects.items() if len(subs) >= GENERIC_CROSS_SUBJECT_THRESHOLD}

def prep_subject(r):
    raw_name = r["subject"]["name"]; addr = r["subject"]["address"]
    pa = r.get("parsedAddress", {}) or {}
    name = clean_name(raw_name)
    nt = tokens(name)
    up_addr = (addr or "").upper()
    return {
        "raw_name": raw_name, "name": name, "name_tokens": nt,
        "surname": nt[-1] if nt else None,
        "careof_tokens": care_of_name(addr),
        "house": (pa.get("houseNumber") or "").upper() or None,
        "area_tokens": [t for t in tokens(pa.get("area") or "") if t not in nt][:4],
        "foreign": any(m in up_addr for m in FOREIGN_MARKERS),
        "address": addr,
        "folio": r["subject"].get("folio",""),
    }

# ---------------------------------------------------------------- run baseline + corrected
base_matched_cases = 0
base_surfaced = 0
corr_call_rows, manual_rows, unresolved_rows, rejected_rows = [], [], [], []
corr_matched_cases = 0
collapse_examples = []
trace_examples = []

for r in records:
    subj = prep_subject(r)
    phones = r["phones"]

    # BASELINE (their logic incl. fallback): non-dummy candidates surface; case "matched" if any
    base_nondummy = [p for p in phones if not is_dummy(p.get("phone",""))]
    if base_nondummy: base_matched_cases += 1
    base_surfaced += len(base_nondummy)

    # CORRECTED
    decided = [evaluate_candidate(p, subj, generic_phones) for p in phones]
    keep = [d for d in decided if d["keep"]]
    # rank A>B>C then by relationship then reliability; cap 3
    order = {"A":0,"B":1,"C":2}
    keep.sort(key=lambda d: (order.get(d["category"],9), -d.get("rel",0), -d.get("rec",0)))
    keep = keep[:MAX_CONTACTS_PER_CASE]
    research = [d for d in decided if d["category"] == "D"]
    rejected = [d for d in decided if d["category"] == "Rejected"]

    if len(phones) >= 400:
        collapse_examples.append((subj["name"], len(phones), len(keep), len(research)))

    if keep:
        corr_matched_cases += 1
        for d in keep:
            corr_call_rows.append([subj["folio"], subj["name"], subj["address"], d["phone"],
                                   d.get("owner") or "", d["category"], d.get("rel"), d.get("rec"),
                                   d.get("nm"), d.get("source")])
    elif research:
        for d in research[:MAX_CONTACTS_PER_CASE]:
            manual_rows.append([subj["folio"], subj["name"], subj["address"], d["phone"],
                                d.get("owner") or "", d["reason"], d.get("source")])
    else:
        reason = "FOREIGN_ADDRESS" if subj["foreign"] else ("NO_CANDIDATE" if not phones else "NO_ANCHOR_ANY")
        unresolved_rows.append([subj["folio"], subj["name"], subj["address"], reason])

    for d in rejected:
        rejected_rows.append([subj["folio"], subj["name"], d["phone"], d["reason"], d.get("source","")])

# representative traces
def find_trace(pred):
    for r in records:
        if pred(r): return r
    return None

# ---------------------------------------------------------------- write sheets
def write(path, header, rows):
    with open(path, "w", newline="") as f:
        w = csv.writer(f); w.writerow(header); w.writerows(rows)

write(f"{OUT}/A_daily_call_sheet.csv",
      ["Folio","Shareholder","Old Address","Phone","Contact Owner","Category","RelationshipScore","ContactReliability","NameMatch","Source"],
      corr_call_rows)
write(f"{OUT}/B_manual_review.csv",
      ["Folio","Shareholder","Old Address","Phone","Owner","Reason","Source"], manual_rows)
write(f"{OUT}/C_unresolved.csv",
      ["Folio","Shareholder","Old Address","Reason"], unresolved_rows)
write(f"{OUT}/D_rejected.csv",
      ["Folio","Shareholder","Phone","RejectionReason","Source"], rejected_rows)

# ---------------------------------------------------------------- report
n = len(records)
print("="*70)
print("CORRECTED-ENGINE REPLAY OVER REAL CACHE  (", n, "investigations )")
print("="*70)
print(f"\nGeneric/directory numbers auto-detected (same phone for >= {GENERIC_CROSS_SUBJECT_THRESHOLD} people): {len(generic_phones)}")
print("\n--- BEFORE (current build, with fallback) ---")
print(f"  Cases marked 'Matched'            : {base_matched_cases} / {n}")
print(f"  Total numbers surfaced to staff   : {base_surfaced}")
print("\n--- AFTER (corrected: anchor gate + block-bound + domain dedup + no fallback) ---")
print(f"  Cases with a call-ready lead (A-C): {corr_matched_cases} / {n}")
print(f"  Numbers on the Daily Call Sheet   : {len(corr_call_rows)}   (max 3/case)")
print(f"  Sent to Manual Review (D)         : {len(manual_rows)}")
print(f"  Unresolved (incl. foreign/no-anchor): {len(unresolved_rows)}")
print(f"  Rejected (kept out of staff view) : {len(rejected_rows)}")
if base_surfaced:
    print(f"\n  Noise removed from staff output   : {base_surfaced - len(corr_call_rows)} "
          f"numbers ({100*(base_surfaced-len(corr_call_rows))/base_surfaced:.1f}% of what staff would have seen)")

rej_reasons = collections.Counter(row[3].split("(")[0] for row in rejected_rows)
print("\n  Why numbers were rejected:")
for k,v in rej_reasons.most_common():
    print(f"    {k:32s} {v}")

print("\n--- MEGA-CASE COLLAPSE (cases that had >=400 raw candidates) ---")
for name, raw, kept, res in sorted(collapse_examples, key=lambda x:-x[1])[:6]:
    print(f"  {raw:4d} raw  ->  {kept} call-ready + {res} research   [{name[:40]}]")

print("\n--- TRACE: the Dubai case (input corruption -> false proxy) ---")
d = data.get("98ed011368e59417a0f44aa7f0a887bd")
if d:
    subj = prep_subject(d)
    print(f"  raw name   : {subj['raw_name']!r}")
    print(f"  cleaned    : {subj['name']!r}   tokens={subj['name_tokens']}  foreign={subj['foreign']}")
    dec = evaluate_candidate(d['phones'][0], subj, generic_phones)
    print(f"  candidate  : {d['phones'][0]['phone']} (was scored {d['phones'][0]['confidence']}, attr {d['phones'][0]['attribution']})")
    print(f"  CORRECTED  : keep={dec['keep']} category={dec['category']} reason={dec['reason']}")
print("\nSheets written to:", OUT)
