# Corrected Contact Finder — Build Package

This package contains the deterministic corrections, **validated on the real 264-case cache**, plus production code to put the same rules into the live app.

## What's here

| File | What it is | Status |
|---|---|---|
| `corrected_engine_replay.py` | Runs the corrected rules over `.cache/investigations.json`, prints before/after, writes the four sheets. | Runs today, offline. |
| `corrected_output/A_daily_call_sheet.csv` | Call-ready leads (A–C), max 3/case, each with two scores + source. | Real output. |
| `corrected_output/B_manual_review.csv` | Category D — plausible, needs a human check before calling. | Real output. |
| `corrected_output/C_unresolved.csv` | No usable route (foreign address, no anchor, no candidate). | Real output. |
| `corrected_output/D_rejected.csv` | Everything kept out of staff view, with the reason. | Real output. |
| `EvidenceGate.ts` | The mandatory anchor gate + junk/source guards. | Strict-typecheck clean. |
| `ConfidenceScorer.corrected.ts` | Dual score (relationship + reliability) + A/B/C/D classifier. | Strict-typecheck clean. |

## What the replay proved on your data

- Before (current build): **139** cases marked "Matched", **~9,300** numbers surfaced to staff.
- After (corrected): **19** cases with a call-ready lead, **34** numbers on the call sheet, 78 to manual review, the rest rejected with a reason.
- **99.6%** of what staff would have seen is removed. Worst classes now reject correctly: foreign-address cases, directory/generic numbers (one number reused across ≥5 people), templated numbers (`6950000022`), no-anchor pages, and wholesale-harvested bill/status pages. The 815-candidate case yields 0 auto-leads.

This is a **lower bound**. The replay re-scores evidence the flawed engine already captured. Turning off Gemini's live search and bounding extraction upstream (Phase 1 of the work order) removes more noise before scoring ever runs.

## How to wire it into the live app

1. **Drop in** `EvidenceGate.ts` and the corrected `ConfidenceScorer.ts` under `lib/engine/attribution/`. Delete the old additive `scoreCandidate`, or keep it only behind the gate.

2. **Build `genericPhones` once per batch** (a number attributed to many different subjects is a directory number, not a personal one):
   ```ts
   const counts = new Map<string, Set<string>>();
   for (const r of allResults)
     for (const p of r.phones)
       (counts.get(p.phone) ?? counts.set(p.phone, new Set()).get(p.phone)!).add(norm(cleanName(r.subject.name)));
   const genericPhones = new Set([...counts].filter(([,s]) => s.size >= 5).map(([ph]) => ph));
   ```

3. **Score through the gate** instead of the old scorer:
   ```ts
   import { scoreCandidateGated, rankForCallSheet } from './attribution/ConfidenceScorer';
   const scored = candidate ? scoreCandidateGated(
     candidate.phone, candidate.owner, candidate.evidence, subject, parsedAddress, genericPhones) : null;
   ```

4. **Fix the export** — `lib/exportExcel.ts`. Two required changes:

   **a. Delete the fallback (lines ~130–133).** Remove this block entirely:
   ```ts
   // DELETE THIS — it re-adds rejected numbers and marks the row "Matched"
   if (candidates.length === 0 && rawCandidates.length > 0) {
     candidates = rawCandidates.filter(c => c.phone && c.phone !== 'Not Found' && !isDummyOrSpamPhone(...));
   }
   ```

   **b. Drive status from category, cap at 3.** Replace the status logic with:
   ```ts
   const callable = rankForCallSheet(scoredCandidates)
     .filter(c => c.category === 'A' || c.category === 'B' || c.category === 'C')
     .slice(0, 3);
   const statusText = r.status !== 'success' ? 'Error'
     : callable.length ? 'Matched' : 'No qualified lead';
   ```
   Never let a below-threshold or D/Rejected candidate onto this sheet.

5. **Write four sheets, not one** (mirror the CSV outputs): Daily Call Sheet (A–C), Manual Review (D), Unresolved, Rejected. The `corrected_output/*.csv` show the exact columns.

6. **Version-stamp the cache** (`FileCacheService.ts`): write `parserVersion`, `engineVersion`, `scoringVersion` into each entry; invalidate on change. The current cache has no version fields, which is why it had to be discarded whole.

## Honest limits — do not skip

- These are **defensible** leads (each has a stated anchor), not **verified-correct** leads. Real precision is unknown until the pilot calls them.
- A few survivors on the call sheet are still shareholder-list-PDF or near-sequential artifacts. That residue is why the human-review step and the upstream extraction fix both exist. I stopped tightening deliberately — further tuning against this cache, without your 48-case answer key, would be circular testing.
- Ingestion (name/address split), turning off the LLM's live search, and bounding extraction to evidence blocks are **not** in this package as live code — they touch `parse-pdf/route.ts`, `GeminiService.ts`, `extractionPrompt.ts` and `PhoneExtractor.ts` and must be done and tested in-repo per the work order. The replay simulates their effect (name cleaning, foreign-address rejection); the live versions will do better.

## Next steps

1. Developer implements Phase 0 + Phase 1 from the work order and drops in this code.
2. Run the replay after each change to watch the numbers move.
3. Run the 48-case benchmark blind (you hold the answer key). Target: ≥30/48 with a reviewable route, wrong-number rate <15%, ≤3 numbers/case, zero fallback-to-Matched.
4. Only then, a controlled 50-record pilot with real calling. Improve on call outcomes, not internal scores.
